#include"head/SqStack.h"
#include"head/LinkStack.h"
#include<stdio.h>
#include<stdlib.h>
#include<windows.h>
int main()
{
  int choice;
    printf("===============ջ=============\n");
    printf("==============================\n");
    printf("==============================\n");
    printf("==============================\n");
    printf("��ѡ��1.˳��ջ 2.��ջ 3.�˳�\n");
    scanf("%d",&choice);
    while(choice!=1&&choice!=2&&choice!=3)
    {
        printf("������ѡ��\n");
        scanf("%d",&choice);
    }
    if(choice==1) printfsystem1();
    else if(choice==2) printfsystem2();
    else
    {
        system("pause");
        exit(1);
    }
	system("pause");
}




