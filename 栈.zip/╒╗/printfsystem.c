#include<stdio.h>
#include<stdlib.h>
#include<windows.h>
#include"head/LinkStack.h"
#include"head/SqStack.h"
#include"head/printfsystem.h"

void printfsystem()
{
    int choice;
    printf("-------------ջ----------\n");
    printf("=========================\n");
    printf("-------------------------\n");
    printf("=========================\n");
    printf("��ѡ�� 1.˳��ջ  2.��ջ\n");
    printf("=========3.�˳�\n");
    scanf("%d",&choice);
    while(choice!=1&&choice!=2)
    {
        printf("������ѡ��\n");
        scanf("%d",&choice);
    }
    if(choice==1) printfsystem1();
    else if(choice==2) printfsystem2();
    else exit(1);
	system("pause");
}




void printfsystem2()
{
    LinkStack topLinkStack;
    topLinkStack.top=NULL;
    int ch;
L:
    system("cls");
    printf("------��ջ-------\n");
    printf("                 \n");
    printf("                 \n");
    printf("-----------------\n");
    printf(">>> 1.��ʼ��     \n");
    printf(">>> 2.��ջ       \n");
    printf(">>> 3.��ջ       \n");
    printf(">>> 4.���       \n");
    printf(">>> 5.����       \n");
    printf(">>> 6.ջ��       \n");
    printf(">>> 7.�Ƿ�Ϊ��   \n");
    printf(">>> 8.���ջ��   \n");
    printf(">>> 9.����       \n");
    printf("-----------------\n");
    printStack(&topLinkStack);
    printf("-----------------\n");
    printf("���������ѡ��:");
    scanf("%d",&ch);
    while(ch<1 || ch>9)
    {
        printf("ѡ������������ѡ��");
        scanf("%d",&ch);

    }
    switch(ch)
    {
        case 1:
        {
            initLStack(&topLinkStack);
            system("pause");
            goto L;
            break;
        }
    case 2:
        {
            int data;
            pushLStack(&topLinkStack,data);
            system("pause");
            goto L;
            break;
        }
    case 3:
        {
            int data1;
            popLStack(&topLinkStack,&data1);
            system("pause");
            goto L;
            break;
        }
        case 4:
        {
            clearLStack(&topLinkStack);
            system("pause");
            goto L;
            break;
        }
        case 5:
        {
            destroyLStack(&topLinkStack);

            system("pause");
            goto L;
            break;
        }
        case 6:
        {
            int length;
            LStackLength(&topLinkStack,&length);
            system("pause");
            goto L;
            break;
        }
        case 7:
        {
            isEmptyLStack(&topLinkStack);
            system("pause");
            goto L;
            break;
        }
        case 8:
        {
            int top;
            getTopLStack(&topLinkStack,&top);
            system("pause");
            goto L;
            break;
        }
        case 9:
        {
            printf("\n\n886!\n\n");
            system("pause");
            printfsystem();
            break;
        }
    }


}
